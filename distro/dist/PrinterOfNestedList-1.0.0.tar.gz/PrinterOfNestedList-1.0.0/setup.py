from distutils.core import setup

setup(
    name = 'PrinterOfNestedList',
    version = '1.0.0',
    py_modules  = ['printNestedList'],
    author = 'Nirmalraj',
    author_email = 'nirmal497@gmail.com',
    url = 'github.com/rajnirmal',
    description = 'This is a simple .py code to print a nested list in a proper manner. Courtesy of Head First Python Book',
)
